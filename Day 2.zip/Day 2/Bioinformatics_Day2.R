## 16S analysis module for Bioinformatics class Day 2

##Setup
#Load packages
library(vegan)

#Working directory
setwd()

#Load data-sets 
#Community data, Format: Samples are rows, ASVs (species) are columns
data <- read.csv("", head = T, row.names = 1, check.names = F) 

#Metadata, Format: samples are rows, variables are columns
metadata <- read.csv("", head = T, row.names=1)

#Check to see that the data tables align
row.names(data) == row.names(metadata)

##Rarefy - making the samples comparable
set.seed(111)
#Check the lowest ASV count
min(rowSums(data))
#rarefy
data.r <- rrarefy(data, sample = )
data.r <- as.data.frame(data.r)

##Alpha diversity
#Calculate alpha diversity, using the Shannon-Weaver index and load as a column in the metadata
metadata$alpha.16s <- diversity() 

#Use a generalized linear model to test if host plant species is driving alpha diversity
model <- glm(alpha.16s ~ Host_Spp, data = , family = "poisson")
summary(model)
#visualize
boxplot(alpha.16s ~ Host_Spp, data = )

##Beta Diversity
#Calculate Bray-Curtis dissimilarity
distance <- vegdist(data.r, method = "bray")
#Calculate PERMANOVA using distance object
adonis(distance ~ Host_Spp, data = )
#Visualize using NMDS
NMDS <- metaMDS(distance, k = 2, trymax = 300)
plot(NMDS$points, col = c("red", "blue", "green")[as.factor(metadata$Host_Spp)],
     pch = 16) #number of colors must match number of host species

##BLAST
#Locate the most abundant ASV at this site
ASV_counts <- colSums()
names(ASV_counts[ASV_counts == max(ASV_counts)])         
#Take the ASV name, search for it in the file "rep-sequences-16s"
#Copy the sequence and ID, enter into BLAST
#Retrieve most likely taxonomy
#Visualize distribution of this ASV in host plant species
boxplot(data.r[,"ASV name goes here"] ~ metadata$Host_Spp, 
        ylab = "Abundance", xlab = "Host Species", main = "Most Abundant ASV")

