#Load packages####
library(vegan)

#Working directory
setwd("C:/Users/Jacob/Desktop/Bioinformatics module/Day 2/Group 5")

##Load data-sets 

#Community data, Format: Samples are rows, ASVs (species) are columns
data <- read.csv("PleaPhaseSavanna_16s_ASVs.csv", head = T, row.names = 1, check.names = F) 

#Metadata, Format: samples are rows, variables are columns
metadata <- read.csv("PleaPhaseSavanna_metadata.csv", head = T, row.names=1)

#Check to see that the data tables align
row.names(data) == row.names(metadata)

##Rarefy - making the samples camparable
set.seed(111)
#Check the lowest ASV count
min(rowSums(data))
#rarefy
data.r <- rrarefy(data, min(rowSums(data)))
data.r <- as.data.frame(data.r)

##Alpha diversity
#Calculate alpha diversity, using the Shannon-Weaver index and load as a column in the metadata
metadata$alpha.16s <- diversity(data.r) 

#Use a generalized linear model to test if host plant species is driving alpha diversity
model <- glm(alpha.16s ~ Host_Spp, data = metadata, family = "poisson")
summary(model)
#visualize
boxplot(alpha.16s ~ Host_Spp, data = metadata, 
        ylab = "alpha diversity", xlab = "Host Species", main = "Alpha diversity by Host Species")

##Beta Diversity
#Calculate Bray-Curtis dissimilarity
distance <- vegdist(data.r, method = "bray")
#Calculate PERMANOVA using distance object
adonis(distance ~ Host_Spp, data = metadata) #PERMANOVA
#Visualize using NMDS
NMDS <- metaMDS(distance, k = 2, trymax = 300)
plot(NMDS$points, col = c("red", "blue", "purple")[as.factor(metadata$Host_Spp)],
     pch = 16, cex = 2, main = "NMDS of host species at Plea Phase Savanna")

##BLAST
#Locate the most abundant ASV at this site
ASV_counts <- colSums(data.r)
names(ASV_counts[ASV_counts == max(ASV_counts)])         
#Take the ASV name, search for it in the file "rep-sequences-16s"
#Copy the sequence and ID, enter into BLAST
#Retrieve most likely taxonomy
#Visualize distribution of this ASV in host plant species
boxplot(data.r[,"44c21e29adae97a53247abbd73978395"] ~ metadata$Host_Spp, 
        ylab = "Abundance", xlab = "Host Species", main = "Rhodanobacter sp.")

